<?php

    // STD-I/O Class

    // Optional library used to communicate with the user
    // KeyPHP Implementation by Louis Bertrand <adressepro111@pylott.yt>

    if (!class_exists('\STDio\stdio')) {
        require_once("links/stdio.php");
    }